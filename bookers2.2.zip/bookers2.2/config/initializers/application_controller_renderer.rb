# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '5c8ce409c3b46aa1e87c6d4c978774a1715651f4b3703c63700d9e0f35d3d66f97261577ca97df80998fa694d30f0ce8b512e48aa0253991116b782d68383bc6'